import tkinter
print("Tkinter is working correctly!")

